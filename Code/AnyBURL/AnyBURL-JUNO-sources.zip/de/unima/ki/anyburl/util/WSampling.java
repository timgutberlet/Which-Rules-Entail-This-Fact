package de.unima.ki.anyburl.util;

public class WSampling {
	
	
	
	
	
	public WSampling() {
		
		
	}
	
	
	public void addEntry(String rule, int frequency) {
		
		
		
	}
	
	public void init() {
		
	}
	

}
