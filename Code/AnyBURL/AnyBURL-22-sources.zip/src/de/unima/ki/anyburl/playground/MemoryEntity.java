package de.unima.ki.anyburl.playground;

public class MemoryEntity {
	
	private String value;
	
	public MemoryEntity(String v) {
		this.value = value;
	}

}
